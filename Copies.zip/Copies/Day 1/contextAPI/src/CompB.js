import React from 'react';
import { upass } from './App';

function CompB(prop) {
    return (
        <>
            <upass.Consumer>
                {
                    (password) => {
                       return <h1>Example for React Context API - {prop.props} & password is {password}</h1>
                    }
                }
            </upass.Consumer>
            {/* <h1>Example for React Context API - {prop.props}</h1> */}
        </>
    );
}

export default CompB;