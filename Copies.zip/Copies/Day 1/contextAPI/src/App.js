import { createContext } from 'react';
import './App.css';
import CompA from './CompA';
import CompC from './CompC';

const upass = createContext();

function App() {

  const uname = 'ContextAPI';

  return (
    <div className="App">
      Learn React
      <upass.Provider value={"Pass@123"}>
        <CompA concept1={uname} />
        <CompC/>
      </upass.Provider>
      {/* <CompA concept1={uname}/> */}
    </div>
  );
}

export default App;
export { upass };