import { upass } from "./App";

function CompC() {
    return ( 
        <>
            <upass.Consumer>
                {
                    (password1)=> {
                        return <h5>This is repeated password from diff comp {password1}</h5>
                    }
                }
            </upass.Consumer>
        </>
     );
}

export default CompC;