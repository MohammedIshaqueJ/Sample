import React from 'react';
import CompB from './CompB';

function CompA(prop) {
    return ( 
        <CompB props={prop.concept1}/>
     );
}

export default CompA;