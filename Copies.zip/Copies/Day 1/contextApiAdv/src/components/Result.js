import React, { useContext, useEffect } from 'react';
import NotesContext from '../context/notes/NotesContext';

function Result() {

    const data = useContext(NotesContext);
    useEffect(()=> {
        data.updatemyState()
    },[]
    )
    return (  
        <h2>My data is mentioned as {data.val.age} and name is {data.val.name}</h2>
    );
}

export default Result;