import './App.css';
import Result from './components/Result';
import NotesState from './context/notes/NotesState';

function App() {
  return (
    <div className="App">     
          Learn React  
          <NotesState>
          <Result/>   
          </NotesState>  
          
    </div>
  );
}

export default App;
