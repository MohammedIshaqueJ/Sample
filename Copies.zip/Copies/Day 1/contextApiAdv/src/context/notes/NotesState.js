import React, { useState } from 'react';
import NotesContext from './NotesContext';

function NotesState(props) {

    const mystate = {
        name: 'Ishq',
        age: 25
    };
    const [val, setVal] = useState(mystate);

    const updatemyState = () => {
        setTimeout(() => {
            setVal(
                {
                    name: 'Bilal',
                    age: 9
                }
            )
        }, 4000);
    }
    return (
        <NotesContext.Provider value={{ val, updatemyState }}>
            {props.children}
        </NotesContext.Provider>
    );
}

export default NotesState;