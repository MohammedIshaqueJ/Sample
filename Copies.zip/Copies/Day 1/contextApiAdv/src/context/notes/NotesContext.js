import {createContext} from 'react';

const NotesContext = createContext();

export default NotesContext;