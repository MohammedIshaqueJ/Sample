import Header from "./Header";
import { useNavigate } from "react-router-dom";

function OrderProduct() {

    const navigate = useNavigate();
    return ( 
            <>
                <Header/>
                <div>Product Ordered Successfully!</div>
                <button onClick={()=> navigate(-1)}>Go Back</button>
            </>
        );
}

export default OrderProduct;