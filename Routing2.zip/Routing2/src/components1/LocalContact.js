function LocalContact() {
    return (  
        <div>
            Localization Contact
        </div>
    );
}

export default LocalContact;