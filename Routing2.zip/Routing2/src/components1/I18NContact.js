function I18NContact() {
    return (  
        <div>
            international contact!!!
        </div>
    );
}

export default I18NContact;