import { NavLink } from "react-router-dom";
import Header from "./Header";
import { useNavigate } from "react-router-dom";

function Home1() {
   const navigate = useNavigate();
  
   return ( 
        <>
       <Header/>
       <button onClick={() => { navigate('order') } }>Goto Order Status</button>
       <button onClick={()=> navigate('order',{replace:true})}>Goto Old Page</button>
            
         <section>
            <h2>Home Page</h2>
         </section>
        </>
     );
}

export default Home1;
<div>Home1 Component</div>