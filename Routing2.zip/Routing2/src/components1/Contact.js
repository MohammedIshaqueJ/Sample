import { NavLink, Outlet } from "react-router-dom";
import Header from "./Header";

function Contact() {
    return (
        <>
            <Header />
            <section>
                <h2>Contact Page</h2>
            </section>
            <NavLink to='i18ncontact'>international</NavLink>
            <NavLink to={'localcontact'}>Localization</NavLink>
            <Outlet/>
        </>
    );
}

export default Contact;
