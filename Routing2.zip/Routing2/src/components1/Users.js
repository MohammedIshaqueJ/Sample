import { useSearchParams } from "react-router-dom";
import About from "./About";

function Users() {

    const [searchParam, setSearchParam] = useSearchParams();
    const showActiveUsers = searchParam.get('filter')=== 'active';
    return (  
       <>
        <div>
            Users Component Loaded!
        </div>
        <h2>User1</h2>
        <h3>User2</h3>
        <h4>User3</h4>
        <button onClick={ ()=> {setSearchParam( {filter:'active'}) }}>Active Users</button>
        <br></br>
        <button onClick={ ()=> {setSearchParam( {} )}}>All Users</button>
        <br></br>
        {
            showActiveUsers? <About/>: <h5>All Users Displayed</h5>
        }
       </>
    );
}

export default Users;