import { useParams } from "react-router-dom";

function UsersDetails() {
    
    const param = useParams();
    const userkey = param.userId
    return ( 
        <div><font color='darkyellow'>Users Details Loaded with id as {userkey}!!!!</font></div>
     );
}

export default UsersDetails;