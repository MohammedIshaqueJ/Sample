import { NavLink } from "react-router-dom";
import Header from "./Header";

function About() {
    return (
        <>
        <Header/>    
        <section>
            <h2>About Page</h2>
         </section>
        </>
    );
}

export default About;
<div>About Component</div>