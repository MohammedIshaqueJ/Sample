function UsersAdmin() {
    return (  
        <div>
            <font color='red'>
                Users Admin!
            </font>
        </div>
    );
}

export default UsersAdmin;