import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './components/Home';
import About from './components1/About';
import Contact from './components1/Contact';
import Home1 from './components1/Home1';
import OrderProduct from './components1/OrderProduct';
import I18NContact from './components1/I18NContact';
import LocalContact from './components1/LocalContact';
import Users from './components1/Users';
import UsersDetails from './components1/UsersDetails';
import UsersAdmin from './components1/UsersAdmin';

function App2() {
  return (
    <div className="App-header">
      Routing
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home1 />} />
          <Route path='/about' element={<About />} />
          <Route path='/contact' element={<Contact/>}>
            <Route index element={<I18NContact/>}></Route>
            <Route path='i18ncontact' element={<I18NContact/>} />
            <Route path='localcontact' element={<LocalContact/>} />
          </Route>
          <Route path="/users" element={<Users/>}></Route>
          {/* <Route path="/users/1" element={<UsersDetails/>}></Route> */}
          <Route path="/users/:userId" element={<UsersDetails/>}></Route>
          <Route path="/users/userAdmin" element={<UsersAdmin/>}></Route>
          <Route path='/order' element={<OrderProduct />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App2;
