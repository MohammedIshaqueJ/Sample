import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact';
import Home1 from './components/Home1';

function App1() {
  return (
    <div className="App-header">
      Routing
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home1/>}/>
          <Route path='/about' element={<About/>}/>
          <Route path='/contact' element={<Contact/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App1;
