import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App-header">
      Routing
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<div>Hello</div>}/>
          <Route path='/about' element={<div>Hello About</div>}/>
          <Route path='/contact' element={<div>Hello Contact</div>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
