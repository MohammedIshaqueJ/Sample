
import Header from "./Header";

function Contact() {
    return ( 
        <>
        <Header/>
         <section>
            <h2>Contact Page</h2>
         </section>
        </>     
        );
}

export default Contact;
