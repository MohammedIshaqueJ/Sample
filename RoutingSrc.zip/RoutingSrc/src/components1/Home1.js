import { NavLink } from "react-router-dom";
import Header from "./Header";

function Home1() {
    return ( 
        <>
       <Header/>
         <section>
            <h2>Home Page</h2>
         </section>
        </>
     );
}

export default Home1;
<div>Home1 Component</div>