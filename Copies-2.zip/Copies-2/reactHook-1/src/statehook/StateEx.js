import React, {useState} from 'react';

function StateEx() {

    const carNo ='TN21AK9500'
    const age=19;
    const [carNum, setCarNum] = useState(carNo);
    const changeNumber = () => {
        // setCarNum('KA21AK9500');
        // console.log('Number Changing');
        
        //if(age>18)
        if(carNum==='TN21AK9500')
        {
            setCarNum('KA21AK4554')
        }else{
            setCarNum('TN21AK9500');
        }
    }

    return (
        <>
            <h1>React useState Hook Example 1</h1>
            <h3>Car Number is {carNum}</h3>
            <button onClick={changeNumber}>Click Me!</button>
        </>
    );
}

export default StateEx;