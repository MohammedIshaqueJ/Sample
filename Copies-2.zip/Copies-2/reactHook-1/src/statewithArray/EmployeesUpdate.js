import { useState } from "react";

function EmployeesUpdate() {

    const employees = { id: 1, name: 'Ishaquebasha', city: 'Kpm' }     
    
    const [emp, setEmp] = useState(employees);

    const clearEmployees = () => {
        setEmp({});
    }

    const updateName = (emp) => {
        setEmp({...employees,name:'Mohammed'})
    }
    const updateCity = (emp) => {
        setEmp({...employees,city:'Bangalore'})
    }
    return (
        <>
            <h3>Employees List:</h3>
            {
            //emp.map(
               // (emp) => {
                    //return 
                    <h4 key={emp.id}>Employee Name is {emp.name} Living in {emp.city}</h4>
              //  }
            //)
            }
            <button onClick={clearEmployees}>CLEAR</button>
            <br></br>
            <button onClick={updateName}>UpdateName</button>
            <br></br>
            <button onClick={updateCity}>UpdateCity</button>
        </>
    );
}

export default EmployeesUpdate;