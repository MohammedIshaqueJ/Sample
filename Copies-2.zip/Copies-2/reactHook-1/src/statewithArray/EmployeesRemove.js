import { useState } from "react";

function EmployeesRemove() {

    const employees = [
        { id: 1, name: 'Ishaque', city: 'Kpm' },
        { id: 2, name: 'MadhuriDixit', city: 'Mumbai' },
        { id: 3, name: 'Anju', city: 'Pune' },
    ]
    const [empArray, setEmpArray] = useState(employees);

    const clearEmployees = () => {
        setEmpArray([]);
    }

    const removeEmp = (id) => {
        console.log('Remove!!! '+ id);
        const newEmpArray = empArray.filter(
            (currVal)=> {
                return currVal.id !== id;                                
            }
        )
        setEmpArray(newEmpArray);
    }

    return (
        <>
            <h3>Employees List:</h3>
            {empArray.map(
                (currentElement) => {
                    return (
                    <h4 key={currentElement.id}>Employee Name is {currentElement.name} Living in {currentElement.city}
                        <button onClick={() => removeEmp(currentElement.id)}>Remove</button>
                    </h4>
                    )
                }
            )
            }
            <button onClick={clearEmployees}>CLEAR</button>
        </>
    );
}

export default EmployeesRemove;