import { useState } from "react";

function Employees() {

    const employees = [
        { id:1, name: 'Ishaque', city: 'Kpm' },
        { id:2, name: 'Madhuri', city: 'Mumbai' },
        { id:3, name: 'Anju', city: 'Pune' },
    ]
    const [empArray, setEmpArray] = useState(employees);

    const clearEmployees = ()=>
    {
        setEmpArray([]);
    }
    return (
        <>
            <h3>Employees List:</h3>
            {/* <h2>Employee Name is {employees[0].name} Living in {employees[0].city}</h2>
            <h2>Employee Name is {employees[1].name} Living in {employees[1].city}</h2> */}
            {/* {employees.map( */}
            {empArray.map(
                (currentElement) => {
                    return <h4 key={currentElement.id}>Employee Name is {currentElement.name} Living in {currentElement.city}</h4>
                }
            )
            }
        <button onClick={clearEmployees}>CLEAR</button>
        </>
    );
}

export default Employees;