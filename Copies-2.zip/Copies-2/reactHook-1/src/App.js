import './App.css';
import StateEx from './statehook/StateEx';
import Employees from './statewithArray/Employees';
import EmployeesRemove from './statewithArray/EmployeesRemove';
import EmployeesUpdate from './statewithArray/EmployeesUpdate';

function App() {
  return (
    <div className="App">
      <StateEx/>
      {/* <Employees/> */}
      {/* <EmployeesUpdate/> */}
      {/* <EmployeesRemove/> */}
    </div>
  );
}

export default App;
