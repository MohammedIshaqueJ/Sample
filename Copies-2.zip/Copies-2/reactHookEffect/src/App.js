import React, { useEffect, useState } from 'react';
import './App.css';
function App() {

  const [count, setcount] = useState(0);
  const [countmin, setcountmin] = useState(10);

  useEffect(
    () => {
      if(count >=1 ) 
      {
      document.title = `Inbox (${count})`
      console.log('Use=Effect!!!');
      }
      else
      {
        document.title = `In-box`;
        console.log('Use=Effect!!!');
      }

    },[countmin])

  console.log('Outside ');
  const click = () => {
    setcount(count + 1);
  }
  const clickmin = () => {
    setcountmin(countmin - 1);
  }
  return (
    <div className="App-header">
      Use Effect !!!---{count} {countmin}
      <button onClick={click}>Click+</button>
      <button onClick={clickmin}>Click-</button>
    </div>
  );
}
export default App;
